#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ull unsigned long long
#define db double
#define all(x) (x).begin(), (x).end()
#define inf (1 << 30)
#define lnf (1LL << 60)
typedef pair<int, int> PII;
constexpr int N = 10 + 7;
constexpr int DIG = (1 << 9);
constexpr int P = 998244353;
int n;

int c[N], len; // 数位存储
int dp[N][DIG];

int dfs(int k, bool limit, bool zero, int dig) {
    if (!k) return __builtin_popcount(dig) == 3;
    if (!limit && !zero && dp[k][dig] != -1) return dp[k][dig];
    const int MaxLen = limit ? c[k] : 9;
    int res = 0;
    for (int i = 0; i <= MaxLen; i++) {
        if (i != 7 && i != 5 && i != 3 && i != 0) continue;
        if (zero && i == 0) {
            res += dfs(k - 1, limit && i == c[k], zero && i == 0, dig);
        } else {
            if (i != 0)
                res += dfs(k - 1, limit && i == c[k], zero && i == 0, dig | (1 << i));
        }
    }
    if (!limit) dp[k][dig] = res;
    return res;
}

int calc(int x) {
    len = 0;
    while (x) {
        c[++len] = x % 10;
        x /= 10;
    }
    memset(dp, -1, sizeof(dp));
    return dfs(len, true, true, 0);
}

int main() {
    freopen("as03.in", "r", stdin);
    freopen("as03.out", "w", stdout);
    scanf("%d", &n);
    printf("%d\n", calc(n));
    return 0;
}