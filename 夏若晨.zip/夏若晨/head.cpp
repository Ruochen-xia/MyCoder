#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ull unsigned long long
#define db double
#define all(x) (x).begin(), (x).end()
#define inf (1 << 30)
#define lnf (1LL << 60)
typedef pair<int, int> PII;
constexpr int N = 1000000000 + 7;
constexpr int P = 998244353;

int main() {
    // freopen("as0x.in", "r", stdin);
    // freopen("as0x.out", "w", stdout);

    return 0;
}