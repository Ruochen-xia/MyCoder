#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ull unsigned long long
#define db double
#define all(x) (x).begin(), (x).end()
#define inf (1 << 30)
#define lnf (1LL << 60)
typedef pair<int, int> PII;
constexpr int N = 1000000000 + 7;
constexpr int P = 998244353;
int X;

int main() {
    freopen("as01.in", "r", stdin);
    freopen("as01.out", "w", stdout);
    scanf("%d", &X);
    if (X == 7 || X == 5 || X == 3) {
        puts("YES");
    } else {
        puts("NO");
    }
    return 0;
}