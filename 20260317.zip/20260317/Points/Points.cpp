#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ull unsigned long long
#define db double
#define all(x) (x).begin(), (x).end()
#define inf (1 << 30)
#define lnf (1LL << 60)
typedef pair<int, int> PII;
constexpr int N = 2e5 + 7;
constexpr int P = 998244353;
int n, m;
PII a[N];

map<ll, ll> f; // 记录"列"最大值

int main() {
    int T;
    scanf("%d", &T);
    while (T--) {
        scanf("%d%d", &n, &m);
        for (int i = 1; i <= n; i++) scanf("%d", &a[i].first);
        for (int i = 1; i <= n; i++) scanf("%d", &a[i].second);
        f.clear();
        auto p2 = [&](ll x) -> ll {
            return x * x;
        };
        for (int i = 1; i <= n; i++) {
            auto [x, r] = a[i];
            for (int j = x - r; j <= x + r; j++) {
                ll Now = (ll)sqrtl(p2(r) - p2(x - j));
                f[j] = max(f[j], Now);
            }
        }
        ll Ans = 0;
        for (auto [fir, sec] : f) Ans += (sec * 2 + 1);
        printf("%lld\n", Ans);
    }
    return 0;
}