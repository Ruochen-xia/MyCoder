#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ull unsigned long long
#define db double
#define all(x) (x).begin(), (x).end()
#define inf (1 << 30)
#define lnf (1LL << 60)
typedef pair<int, int> PII;
constexpr int N = 20 + 7;
constexpr int P = 998244353;
constexpr int X = 753;
char s[N];
int n;

int Ans = inf;

int main() {
    freopen("as02.in", "r", stdin);
    freopen("as02.out", "w", stdout);
    scanf("%s", s + 1);
    n = strlen(s + 1);
    for (int i = 1; i <= n - 2; i++) {
        string NowStr;
        for (int j = 0, k = i; j < 3; j++, k++) {
            NowStr += s[k];
        }
        int NowNum = atoi(NowStr.c_str());
        Ans = min(Ans, abs(NowNum - X));
    }
    printf("%d\n", Ans);
    return 0;
}