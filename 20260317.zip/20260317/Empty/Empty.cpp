#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ull unsigned long long
#define db double
#define all(x) (x).begin(), (x).end()
#define inf (1 << 30)
#define lnf (1LL << 60)
typedef pair<int, int> PII;
constexpr int N = 1000000000 + 7;
constexpr int P = 998244353;
mt19937_64 myrand(chrono::steady_clock::now().time_since_epoch().count());

namespace io {
    int Now; // 交互时的数

    void ask(int i, int j, int k) { // 查询
        // ? i j k
        cout << '?' << ' ' << i << ' ' << j << ' ' << k << endl;
        cin >> Now;
    }

    void putAns(int i, int j, int k) { // 输出
        // ! i j k
        cout << '!' << ' ' << i << ' ' << j << ' ' << k << endl;
    }
}

int n;

int now1, now2, now3; // 三个变量

void solve() {
    cin >> n;
    now1 = 1; now2 = 2; now3 = 3;
    for (;;) {
        // 开始跑
        io::ask(now1, now2, now3);
        if (!io::Now) {
            io::putAns(now1, now2, now3);
            return;
        } else if (io::Now == -1) {
            break;
        }
        // 随机操作 [0, 2]
        int id = io::Now;
        unsigned ll rnd = myrand() % 3;
        switch (rnd) {
            case 0:
                now1 = id; break;
            case 1:
                now2 = id; break;
            case 2:
                now3 = id; break;
            default:
                assert(0); break;
        };
    }
    assert(0);
}

int main() {
    int T;
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}