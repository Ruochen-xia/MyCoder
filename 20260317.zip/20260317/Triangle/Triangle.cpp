#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ull unsigned long long
#define db double
#define all(x) (x).begin(), (x).end()
#define inf (1 << 30)
#define lnf (1LL << 60)
typedef pair<int, int> PII;
constexpr int N = 1000000000 + 7;
constexpr int P = 998244353;
int x;

int ck(int a, int b) {
    int c = (a ^ b);
    return (a + b > c && a + c > b && b + c > a) ? b : -1;
}

int calc(int a) {
    int b = a - 1;
    if (ck(a, b) >= 0) return b;
    b = a / 2;
    if (ck(a, b) >= 0) return b;
    b = (a + 1) / 2;
    if (ck(a, b) >= 0) return b;   
    b = 1;
    if (ck(a, b) >= 0) return b;
    return -1;
}

int main() {
    int T;
    scanf("%d", &T);
    while (T--) {
        scanf("%d", &x); 
        printf("%d\n", calc(x));
    }
    return 0;
}